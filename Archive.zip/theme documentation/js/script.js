(function(){
 prettyPrint();
})();